'use client';

import React, { useState } from 'react';
import { Globe, Lock, CheckCircle, Image as ImageIcon, Send, Sparkles, ShieldCheck } from 'lucide-react';

export default function SEOAgentDashboard() {
  const [keywords, setKeywords] = useState('');
  const [country, setCountry] = useState('United States');
  const [step, setStep] = useState<'idle' | 'researching' | 'generating' | 'review' | 'publishing' | 'done'>('idle');
  const [error, setError] = useState('');

  const [research, setResearch] = useState<any>(null);
  const [article, setArticle] = useState<any>(null);
  const [images, setImages] = useState<any[]>([]);

  const [wpUrl, setWpUrl] = useState('');
  const [username, setUsername] = useState('');
  const [appPassword, setAppPassword] = useState('');
  const [vaultToken, setVaultToken] = useState('');
  const [categories, setCategories] = useState<{ id: number; name: string }[]>([]);
  const [authors, setAuthors] = useState<{ id: number; name: string }[]>([]);
  const [selectedCategory, setSelectedCategory] = useState<number>(1);
  const [selectedAuthor, setSelectedAuthor] = useState<number>(1);
  const [seoPlugin, setSeoPlugin] = useState<'yoast' | 'rankmath'>('yoast');
  const [publishMode, setPublishMode] = useState<'publish' | 'future' | 'draft'>('publish');
  const [scheduleDate, setScheduleDate] = useState('');
  const [publishedUrl, setPublishedUrl] = useState('');

  async function startAgentWorkflow(e: React.FormEvent) {
    e.preventDefault();
    setError('');
    setStep('researching');

    try {
      const res1 = await fetch('/api/research', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ keywords, country }),
      });
      const data1 = await res1.json();
      if (!data1.success) throw new Error(data1.error);
      setResearch(data1.research);

      setStep('generating');
      const res2 = await fetch('/api/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ research: data1.research }),
      });
      const data2 = await res2.json();
      if (!data2.success) throw new Error(data2.error);

      setArticle(data2.article);
      setImages(data2.images);
      setStep('review');
    } catch (err: any) {
      setError(err.message);
      setStep('idle');
    }
  }

  async function connectWordPressVault() {
    setError('');
    try {
      const res = await fetch('/api/wp-meta', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ wpUrl, username, appPassword }),
      });
      const data = await res.json();
      if (!data.success) throw new Error(data.error);

      setVaultToken(data.vaultToken);
      setCategories(data.categories);
      setAuthors(data.authors);
      if (data.categories[0]) setSelectedCategory(data.categories[0].id);
      if (data.authors[0]) setSelectedAuthor(data.authors[0].id);
      localStorage.setItem('wp_vault_token', data.vaultToken);
    } catch (err: any) {
      setError(err.message);
    }
  }

  async function approveAndPublish() {
    if (!vaultToken) {
      setError('Please connect your WordPress Secure Vault first.');
      return;
    }
    setError('');
    setStep('publishing');

    try {
      const res = await fetch('/api/publish', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          vaultToken,
          article,
          images,
          categoryId: selectedCategory,
          authorId: selectedAuthor,
          seoPlugin,
          publishMode,
          scheduleDate,
        }),
      });
      const data = await res.json();
      if (!data.success) throw new Error(data.error);

      setPublishedUrl(data.postUrl);
      setStep('done');
    } catch (err: any) {
      setError(err.message);
      setStep('review');
    }
  }

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 p-6 md:p-10 font-sans">
      <div className="max-w-6xl mx-auto space-y-8">
        <header className="border-b border-slate-800 pb-6 flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <h1 className="text-3xl font-bold text-white flex items-center gap-3">
              <Sparkles className="text-sky-400" /> Autonomous SEO, GEO & WordPress Agent
            </h1>
            <p className="text-slate-400 mt-1">
              Ahrefs + Google SERP Browser Research • Grade 3–5 Humanized Writing • &lt;100KB WebP • Yoast & Rank Math Auto-Publisher
            </p>
          </div>
          <span className="px-3 py-1 rounded-full text-xs font-semibold bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
            Vercel Serverless Ready
          </span>
        </header>

        {error && (
          <div className="p-4 rounded-xl bg-red-500/10 border border-red-500/40 text-red-300 text-sm">
            <strong>Error:</strong> {error}
          </div>
        )}

        <form onSubmit={startAgentWorkflow} className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="md:col-span-2">
              <label className="block text-sm font-medium text-slate-300 mb-2">
                Target Keyword or Multiple Keywords (comma-separated)
              </label>
              <input
                type="text"
                required
                placeholder="e.g., best heartwarming birthday wishes for brother, birthday quotes"
                value={keywords}
                onChange={(e) => setKeywords(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-4 py-3 text-white focus:border-sky-400 focus:outline-none"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-2">Target Country (SERP)</label>
              <input
                type="text"
                value={country}
                onChange={(e) => setCountry(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-4 py-3 text-white focus:border-sky-400 focus:outline-none"
              />
            </div>
          </div>

          <button
            type="submit"
            disabled={step === 'researching' || step === 'generating'}
            className="px-6 py-3 rounded-xl bg-sky-500 hover:bg-sky-400 disabled:opacity-50 text-slate-950 font-bold flex items-center gap-2 transition"
          >
            <Globe className="w-5 h-5" />
            {step === 'researching'
              ? 'Step 1/2: Inspecting Ahrefs & Google SERP...'
              : step === 'generating'
              ? 'Step 2/2: Writing Grade 3-5 Article & Compressing <100KB WebP...'
              : 'Launch Autonomous Research & Draft'}
          </button>
        </form>

        {article && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2 space-y-6">
              <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-3">
                <div className="flex items-center justify-between">
                  <h2 className="text-lg font-bold text-sky-400">Yoast / Rank Math SEO Snippet Preview</h2>
                  <span className="text-xs px-2.5 py-1 rounded bg-emerald-500/20 text-emerald-300">
                    Readability: {article.readability_grade || 'Grade 4'}
                  </span>
                </div>
                <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-1">
                  <p className="text-xs text-emerald-400">/{article.slug}</p>
                  <p className="text-lg text-blue-400 font-semibold">{article.seo_title}</p>
                  <p className="text-sm text-slate-400">{article.meta_description}</p>
                </div>
              </div>

              <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-4">
                <h2 className="text-lg font-bold text-white flex items-center gap-2">
                  <ImageIcon className="w-5 h-5 text-sky-400" /> Generated WebP Images (Strictly &lt; 100 KB)
                </h2>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {images.map((img) => (
                    <div key={img.id} className="bg-slate-950 border border-slate-800 rounded-xl overflow-hidden">
                      <img src={img.base64DataUrl} alt={img.alt} className="w-full h-36 object-cover" />
                      <div className="p-3 space-y-1">
                        <div className="flex justify-between text-xs">
                          <span className="font-bold uppercase text-sky-400">{img.id}</span>
                          <span className="text-emerald-400 font-semibold">{img.sizeKB} KB (.webp)</span>
                        </div>
                        <p className="text-xs text-slate-400 truncate">{img.alt}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-4">
                <span className="text-xs uppercase tracking-wider text-slate-400">Single H1 Heading</span>
                <input
                  type="text"
                  value={article.h1_title}
                  onChange={(e) => setArticle({ ...article, h1_title: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-4 py-2.5 text-xl font-bold text-white"
                />
                <div
                  className="prose prose-invert max-w-none bg-slate-950 p-6 rounded-xl border border-slate-800 text-slate-200 space-y-4"
                  dangerouslySetInnerHTML={{ __html: article.html_body }}
                />
              </div>
            </div>

            <div className="space-y-6">
              <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-4">
                <h2 className="text-lg font-bold text-white flex items-center gap-2">
                  <Lock className="w-5 h-5 text-amber-400" /> Secure WordPress Vault (AES-256)
                </h2>

                {!vaultToken ? (
                  <div className="space-y-3">
                    <input
                      type="url"
                      placeholder="https://yoursite.com"
                      value={wpUrl}
                      onChange={(e) => setWpUrl(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3.5 py-2.5 text-sm"
                    />
                    <input
                      type="text"
                      placeholder="WordPress Username"
                      value={username}
                      onChange={(e) => setUsername(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3.5 py-2.5 text-sm"
                    />
                    <input
                      type="password"
                      placeholder="WP Application Password"
                      value={appPassword}
                      onChange={(e) => setAppPassword(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3.5 py-2.5 text-sm"
                    />
                    <button
                      type="button"
                      onClick={connectWordPressVault}
                      className="w-full py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-sm transition"
                    >
                      Encrypt & Connect WordPress
                    </button>
                  </div>
                ) : (
                  <div className="p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-between">
                    <span className="text-xs text-emerald-300 flex items-center gap-2">
                      <ShieldCheck className="w-4 h-4" /> Credentials Encrypted & Connected
                    </span>
                    <button
                      onClick={() => setVaultToken('')}
                      className="text-xs text-slate-400 underline hover:text-white"
                    >
                      Change
                    </button>
                  </div>
                )}

                <hr className="border-slate-800" />

                <div className="space-y-3">
                  <div>
                    <label className="block text-xs text-slate-400 mb-1">SEO Plugin Target</label>
                    <select
                      value={seoPlugin}
                      onChange={(e) => setSeoPlugin(e.target.value as any)}
                      className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-sm"
                    >
                      <option value="yoast">Yoast SEO</option>
                      <option value="rankmath">Rank Math SEO</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs text-slate-400 mb-1">Select Category</label>
                    <select
                      value={selectedCategory}
                      onChange={(e) => setSelectedCategory(Number(e.target.value))}
                      className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-sm"
                    >
                      {categories.length > 0 ? (
                        categories.map((c) => (
                          <option key={c.id} value={c.id}>{c.name}</option>
                        ))
                      ) : (
                        <option value={1}>Default Category (Connect Vault to load)</option>
                      )}
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs text-slate-400 mb-1">Select Author</label>
                    <select
                      value={selectedAuthor}
                      onChange={(e) => setSelectedAuthor(Number(e.target.value))}
                      className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-sm"
                    >
                      {authors.length > 0 ? (
                        authors.map((a) => (
                          <option key={a.id} value={a.id}>{a.name}</option>
                        ))
                      ) : (
                        <option value={1}>Default Author (Connect Vault to load)</option>
                      )}
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs text-slate-400 mb-1">Publish Action</label>
                    <select
                      value={publishMode}
                      onChange={(e) => setPublishMode(e.target.value as any)}
                      className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-sm"
                    >
                      <option value="publish">Publish Immediately</option>
                      <option value="future">Schedule for Later</option>
                      <option value="draft">Save as Draft</option>
                    </select>
                  </div>

                  {publishMode === 'future' && (
                    <div>
                      <label className="block text-xs text-slate-400 mb-1">Schedule Date & Time</label>
                      <input
                        type="datetime-local"
                        value={scheduleDate}
                        onChange={(e) => setScheduleDate(e.target.value)}
                        className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-sm"
                      />
                    </div>
                  )}

                  <button
                    type="button"
                    onClick={approveAndPublish}
                    disabled={step === 'publishing'}
                    className="w-full py-3.5 mt-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold flex items-center justify-center gap-2 transition"
                  >
                    <Send className="w-4 h-4" />
                    {step === 'publishing'
                      ? 'Uploading WebP & Publishing...'
                      : 'Grant Permission & Publish to WP'}
                  </button>
                </div>

                {step === 'done' && publishedUrl && (
                  <div className="p-4 rounded-xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-200 text-sm space-y-2">
                    <div className="flex items-center gap-2 font-bold">
                      <CheckCircle className="w-4 h-4" /> Published Successfully!
                    </div>
                    <a
                      href={publishedUrl}
                      target="_blank"
                      rel="noreferrer"
                      className="underline text-sky-300 block break-all"
                    >
                      {publishedUrl}
                    </a>
                  </div>
                )}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
