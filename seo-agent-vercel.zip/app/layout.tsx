import './globals.css';
import type { Metadata } from 'next';

export const metadata: Metadata = {
  title: 'Autonomous SEO, GEO & WordPress Publishing Agent',
  description: 'Ahrefs + Google SERP Research, Grade 3-5 Humanized Content, <100KB WebP & WP Auto-Publisher',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
