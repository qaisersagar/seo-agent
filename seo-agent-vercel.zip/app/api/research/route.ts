import { NextResponse } from 'next/server';
import { chromium } from 'playwright-core';
import { GoogleGenAI } from '@google/genai';

export const maxDuration = 60;

export async function POST(req: Request) {
  try {
    const { keywords, country = 'United States' } = await req.json();
    const primaryKeyword = Array.isArray(keywords) ? keywords[0] : keywords.split(',')[0].trim();
    const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

    let rawBrowserData = '';

    if (process.env.CLOUD_BROWSER_WS_ENDPOINT) {
      const browser = await chromium.connectOverCDP(process.env.CLOUD_BROWSER_WS_ENDPOINT);
      const context = browser.contexts()[0] || (await browser.newContext());
      const page = await context.newPage();

      try {
        await page.goto(`https://www.google.com/search?q=${encodeURIComponent(primaryKeyword)}&gl=us&hl=en`, {
          waitUntil: 'domcontentloaded',
          timeout: 20000,
        });
        const serpText = await page.locator('body').innerText();
        rawBrowserData += `LIVE GOOGLE SERP DATA:\n${serpText.slice(0, 6000)}\n\n`;
      } catch (e) {
        console.warn('Cloud browser fallback triggered:', e);
      } finally {
        await browser.close();
      }
    }

    const researchPrompt = `
You are an SEO & Ahrefs Keyword Research Agent. Analyze the target keyword(s): "${keywords}" for ${country}.
${rawBrowserData ? `Use this captured browser data:\n${rawBrowserData}` : 'Use live Google Search grounding to inspect the current top-ranking results and People Also Ask questions.'}

Return ONLY valid JSON with this exact structure:
{
  "primaryKeyword": "${primaryKeyword}",
  "searchIntent": "Informational / Commercial / Transactional",
  "ahrefsKeywords": [
    { "keyword": "string", "volume": "est. monthly volume", "kd": "est. KD 1-100" }
  ],
  "lsiAndNlpEntities": ["entity1", "entity2", "entity3", "entity4", "entity5", "entity6"],
  "peopleAlsoAsk": ["Question 1?", "Question 2?", "Question 3?", "Question 4?", "Question 5?"],
  "competitorGaps": ["Gap 1 to beat competitors", "Gap 2", "Gap 3"],
  "recommendedH2s": ["H2 Heading 1", "H2 Heading 2", "H2 Heading 3", "H2 Heading 4", "H2 Heading 5"]
}`;

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-pro',
      contents: researchPrompt,
      config: {
        tools: [{ googleSearch: {} }],
        responseMimeType: 'application/json',
      },
    });

    const researchData = JSON.parse(response.text || '{}');
    return NextResponse.json({ success: true, research: researchData });
  } catch (error: any) {
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}
