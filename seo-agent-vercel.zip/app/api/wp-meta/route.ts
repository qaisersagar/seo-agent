import { NextResponse } from 'next/server';
import { encryptCredentials, decryptCredentials } from '@/lib/vault';

export async function POST(req: Request) {
  try {
    const body = await req.json();
    let creds = body.vaultToken ? decryptCredentials(body.vaultToken) : {
      wpUrl: body.wpUrl.replace(/\/$/, ''),
      username: body.username,
      appPassword: body.appPassword,
    };

    const vaultToken = body.vaultToken || encryptCredentials(creds);
    const authHeader = 'Basic ' + Buffer.from(`${creds.username}:${creds.appPassword}`).toString('base64');

    const [catRes, userRes] = await Promise.all([
      fetch(`${creds.wpUrl}/wp-json/wp/v2/categories?per_page=50`, {
        headers: { Authorization: authHeader },
      }),
      fetch(`${creds.wpUrl}/wp-json/wp/v2/users?per_page=50`, {
        headers: { Authorization: authHeader },
      }),
    ]);

    if (!catRes.ok) {
      throw new Error(`WordPress connection failed (${catRes.status}). Check URL & Application Password.`);
    }

    const categories = await catRes.json();
    const authors = userRes.ok ? await userRes.json() : [{ id: 1, name: creds.username }];

    return NextResponse.json({
      success: true,
      vaultToken,
      categories: categories.map((c: any) => ({ id: c.id, name: c.name })),
      authors: authors.map((u: any) => ({ id: u.id, name: u.name })),
    });
  } catch (error: any) {
    return NextResponse.json({ success: false, error: error.message }, { status: 400 });
  }
}
