import { NextResponse } from 'next/server';
import { GoogleGenAI } from '@google/genai';
import { compressToWebPUnder100KB } from '@/lib/webp-compressor';

export const maxDuration = 60;

export async function POST(req: Request) {
  try {
    const { research } = await req.json();
    const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

    const prompt = `
You are an elite human SEO, GEO, AEO, and SXO editorial writer. Write a 100% original, high-ranking article based on this research memory:
${JSON.stringify(research, null, 2)}

STRICT MANDATORY RULES:
1. GRADE 3-5 READABILITY (HEMINGWAY STYLE):
   - Write short, clear, active sentences (10-16 words average).
   - Use simple words a 4th grader understands effortlessly.
   - Make it highly skimmable with bullet points, numbered lists, and bold key takeaways.
2. 100% HUMANIZED & ANTI-ROBOTIC:
   - Write with natural human rhythm, practical examples, and direct answers.
   - BANNED WORDS: Never use "delve", "tapestry", "testament", "in today's fast-paced world", "unlock", "elevate", "game-changer", "realm", "beacon", or "moreover".
   - Never copy sentences from other sites; only cite verified universal truths or attributed sayings.
3. HEADING HIERARCHY:
   - Provide ONLY ONE H1 title (in the JSON h1_title field).
   - Inside html_body, use ONLY <h2> and <h3> tags. Never put another <h1> inside html_body.
4. INTRODUCTION (FEATURED SNIPPET READY):
   - Include the exact Primary Keyword ("${research.primaryKeyword}") in the very first sentence.
   - Immediately deliver a 42-50 word Featured Snippet answer block in bold/clear prose that Google AI Overviews and Featured Snippets can lift directly.
5. SEO, GEO, AEO, SXO & E-E-A-T:
   - Naturally weave in all LSI/NLP entities: ${(research.lsiAndNlpEntities || []).join(', ')}.
   - Include a dedicated <h2>Frequently Asked Questions</h2> section answering 5 questions from the research using <h3> tags for each question and direct 2-sentence answers.
6. CONCLUSION (EXTERNAL NOFOLLOW DICTIONARY LINK):
   - Include a <h2>Conclusion</h2> section that contains the primary keyword.
   - Inside the conclusion, naturally hyperlink ONE important concept word to an official Merriam-Webster or Cambridge Dictionary definition page with explicit rel="nofollow noopener" target="_blank" attributes (e.g., <a href="https://www.merriam-webster.com/dictionary/strategy" target="_blank" rel="nofollow noopener">strategy</a>).
7. IMAGE PROMPTS:
   - Create 3 image generation prompts (1 Hero/Featured image + 2 In-Body section illustrations).

Return ONLY valid JSON matching this schema:
{
  "h1_title": "Humanized Click-Worthy H1 Title with Primary Keyword",
  "seo_title": "Optimized Meta Title (50-58 chars, includes Primary Keyword)",
  "slug": "short-keyword-slug",
  "meta_description": "Click-worthy meta description (140-155 chars) with primary keyword and clear benefit.",
  "focus_keyphrase": "${research.primaryKeyword}",
  "readability_grade": "Grade 4",
  "html_body": "Full semantic HTML body (<h2>, <h3>, <p>, <ul>, <li>, <table>) with [IMAGE_1] and [IMAGE_2] placeholders placed between major sections.",
  "image_specs": [
    { "id": "hero", "alt": "Keyword-rich alt text", "prompt": "Clean, modern editorial photograph or illustration representing..." },
    { "id": "IMAGE_1", "alt": "Descriptive alt text for section 1", "prompt": "Clear visual diagram or photo illustrating..." },
    { "id": "IMAGE_2", "alt": "Descriptive alt text for section 2", "prompt": "Clear visual photo illustrating..." }
  ]
}`;

    const articleRes = await ai.models.generateContent({
      model: 'gemini-2.5-pro',
      contents: prompt,
      config: { responseMimeType: 'application/json' },
    });

    const article = JSON.parse(articleRes.text || '{}');

    const generatedImages = [];
    for (const spec of article.image_specs || []) {
      let rawBuffer: Buffer;
      try {
        const imgRes = await ai.models.generateImages({
          model: 'imagen-3.0-generate-002',
          prompt: spec.prompt,
          config: { numberOfImages: 1, outputMimeType: 'image/jpeg', aspectRatio: '16:9' },
        });
        const b64 = imgRes.generatedImages?.[0]?.image?.imageBytes;
        rawBuffer = b64 ? Buffer.from(b64, 'base64') : await createFallbackBanner(spec.alt);
      } catch {
        rawBuffer = await createFallbackBanner(spec.alt);
      }

      const { buffer: webpBuffer, sizeKB } = await compressToWebPUnder100KB(rawBuffer, 98);
      generatedImages.push({
        id: spec.id,
        alt: spec.alt,
        sizeKB,
        base64DataUrl: `data:image/webp;base64,${webpBuffer.toString('base64')}`,
      });
    }

    return NextResponse.json({
      success: true,
      article,
      images: generatedImages,
    });
  } catch (error: any) {
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}

async function createFallbackBanner(titleText: string): Promise<Buffer> {
  const safeText = titleText.replace(/[<>&"']/g, '').slice(0, 55);
  const svg = `
    <svg width="1200" height="675" xmlns="http://www.w3.org/2000/svg">
      <defs>
        <linearGradient id="bg" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stop-color="#0f172a"/>
          <stop offset="100%" stop-color="#1e3a8a"/>
        </linearGradient>
      </defs>
      <rect width="1200" height="675" fill="url(#bg)"/>
      <rect x="60" y="60" width="1080" height="555" rx="24" fill="#1e293b" stroke="#38bdf8" stroke-width="3"/>
      <text x="600" y="320" font-family="Arial, sans-serif" font-size="42" font-weight="bold" fill="#f8fafc" text-anchor="middle">${safeText}</text>
      <text x="600" y="390" font-family="Arial, sans-serif" font-size="24" fill="#38bdf8" text-anchor="middle">SEO • GEO • AEO Optimized Visual (&lt;100KB WebP)</text>
    </svg>`;
  return Buffer.from(svg);
}
