import { NextResponse } from 'next/server';
import { decryptCredentials } from '@/lib/vault';

export const maxDuration = 60;

export async function POST(req: Request) {
  try {
    const {
      vaultToken,
      article,
      images,
      categoryId,
      authorId,
      seoPlugin,
      publishMode,
      scheduleDate,
    } = await req.json();

    const creds = decryptCredentials(vaultToken);
    const apiBase = `${creds.wpUrl}/wp-json/wp/v2`;
    const authHeader = 'Basic ' + Buffer.from(`${creds.username}:${creds.appPassword}`).toString('base64');

    let featuredMediaId = 0;
    let finalHtmlBody = article.html_body;

    for (let i = 0; i < images.length; i++) {
      const img = images[i];
      const base64Raw = img.base64DataUrl.replace(/^data:image\/webp;base64,/, '');
      const imgBuffer = Buffer.from(base64Raw, 'base64');
      const filename = `${article.slug}-${img.id.toLowerCase()}.webp`;

      const uploadRes = await fetch(`${apiBase}/media`, {
        method: 'POST',
        headers: {
          Authorization: authHeader,
          'Content-Disposition': `attachment; filename="${filename}"`,
          'Content-Type': 'image/webp',
        },
        body: imgBuffer,
      });

      if (uploadRes.ok) {
        const mediaData = await uploadRes.json();
        await fetch(`${apiBase}/media/${mediaData.id}`, {
          method: 'POST',
          headers: { Authorization: authHeader, 'Content-Type': 'application/json' },
          body: JSON.stringify({ alt_text: img.alt }),
        });

        if (img.id === 'hero') {
          featuredMediaId = mediaData.id;
        } else {
          const imgHtml = `<figure class="wp-block-image size-large"><img src="${mediaData.source_url}" alt="${img.alt}" loading="lazy" /><figcaption>${img.alt}</figcaption></figure>`;
          finalHtmlBody = finalHtmlBody.replace(`[${img.id}]`, imgHtml);
        }
      }
    }

    finalHtmlBody = finalHtmlBody.replace(/\[IMAGE_\d+\]/g, '');

    const metaFields: Record<string, string> =
      seoPlugin === 'rankmath'
        ? {
            rank_math_focus_keyword: article.focus_keyphrase,
            rank_math_title: article.seo_title,
            rank_math_description: article.meta_description,
          }
        : {
            _yoast_wpseo_focuskw: article.focus_keyphrase,
            _yoast_wpseo_title: article.seo_title,
            _yoast_wpseo_metadesc: article.meta_description,
          };

    const postPayload: any = {
      title: article.h1_title,
      slug: article.slug,
      content: finalHtmlBody,
      status: publishMode,
      categories: [Number(categoryId)],
      author: Number(authorId),
      meta: metaFields,
    };

    if (featuredMediaId) {
      postPayload.featured_media = featuredMediaId;
    }
    if (publishMode === 'future' && scheduleDate) {
      postPayload.date = new Date(scheduleDate).toISOString();
    }

    const postRes = await fetch(`${apiBase}/posts`, {
      method: 'POST',
      headers: {
        Authorization: authHeader,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(postPayload),
    });

    if (!postRes.ok) {
      const errText = await postRes.text();
      throw new Error(`WP Publish Error: ${errText}`);
    }

    const publishedPost = await postRes.json();
    return NextResponse.json({
      success: true,
      postUrl: publishedPost.link,
      postId: publishedPost.id,
      status: publishedPost.status,
    });
  } catch (error: any) {
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}
