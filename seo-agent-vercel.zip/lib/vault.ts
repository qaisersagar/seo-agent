import crypto from 'crypto';

const ALGORITHM = 'aes-256-gcm';
const SECRET = process.env.VAULT_SECRET_KEY || '0123456789abcdef0123456789abcdef';
const KEY = crypto.scryptSync(SECRET, 'salt', 32);

export interface WPCredentials {
  wpUrl: string;
  username: string;
  appPassword: string;
}

export function encryptCredentials(creds: WPCredentials): string {
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv(ALGORITHM, KEY, iv);
  let encrypted = cipher.update(JSON.stringify(creds), 'utf8', 'hex');
  encrypted += cipher.final('hex');
  const authTag = cipher.getAuthTag().toString('hex');
  return `${iv.toString('hex')}:${authTag}:${encrypted}`;
}

export function decryptCredentials(token: string): WPCredentials {
  const [ivHex, authTagHex, encryptedHex] = token.split(':');
  const decipher = crypto.createDecipheriv(ALGORITHM, KEY, Buffer.from(ivHex, 'hex'));
  decipher.setAuthTag(Buffer.from(authTagHex, 'hex'));
  let decrypted = decipher.update(encryptedHex, 'hex', 'utf8');
  decrypted += decipher.final('utf8');
  return JSON.parse(decrypted);
}
