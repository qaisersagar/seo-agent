import sharp from 'sharp';

export async function compressToWebPUnder100KB(
  inputBuffer: Buffer,
  maxKB: number = 98
): Promise<{ buffer: Buffer; sizeKB: number }> {
  let width = 1200;
  let quality = 85;

  while (quality >= 25) {
    const outputBuffer = await sharp(inputBuffer)
      .resize({ width, withoutEnlargement: true })
      .webp({ quality, effort: 6 })
      .toBuffer();

    const sizeKB = Math.round((outputBuffer.byteLength / 1024) * 10) / 10;
    if (sizeKB <= maxKB) {
      return { buffer: outputBuffer, sizeKB };
    }
    quality -= 8;
  }

  const fallbackBuffer = await sharp(inputBuffer)
    .resize({ width: 800, withoutEnlargement: true })
    .webp({ quality: 60, effort: 6 })
    .toBuffer();

  return {
    buffer: fallbackBuffer,
    sizeKB: Math.round((fallbackBuffer.byteLength / 1024) * 10) / 10,
  };
}
